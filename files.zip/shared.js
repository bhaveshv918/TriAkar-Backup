/* ============================================================
   TRIAKAR — SHARED JAVASCRIPT
   Cart state, Razorpay checkout, cursor, nav, reveal
   ============================================================ */

// ===== CUSTOM CURSOR =====
(function() {
  const cursor = document.querySelector('.cursor');
  const ring   = document.querySelector('.cursor-ring');
  if (!cursor || !ring) return;
  let mx = 0, my = 0, rx = 0, ry = 0;
  document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });
  cursor.style.left = '0px'; cursor.style.top = '0px';
  ring.style.left   = '0px'; ring.style.top  = '0px';
  (function animate() {
    rx += (mx - rx) * 0.14;
    ry += (my - ry) * 0.14;
    cursor.style.left = mx + 'px'; cursor.style.top = my + 'px';
    ring.style.left   = rx + 'px'; ring.style.top  = ry + 'px';
    requestAnimationFrame(animate);
  })();
})();

// ===== SCROLL REVEAL =====
(function() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
  }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
})();

// ===== NAV SCROLL =====
(function() {
  const nav = document.querySelector('nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  });
  // mobile toggle
  const toggle = document.querySelector('.nav-toggle');
  const center = document.querySelector('.nav-center');
  if (toggle && center) {
    toggle.addEventListener('click', () => {
      const open = center.classList.toggle('mobile-open');
      center.style.cssText = open
        ? 'display:flex;flex-direction:column;position:fixed;top:var(--nav-h);left:0;right:0;background:var(--ivory);padding:24px 20px;gap:18px;border-bottom:1px solid var(--stone-pale);z-index:499;'
        : '';
    });
  }
})();

// ===== CART STATE =====
const Cart = (function() {
  let items = JSON.parse(localStorage.getItem('ta_cart') || '[]');

  function save() { localStorage.setItem('ta_cart', JSON.stringify(items)); updateBadge(); }

  function updateBadge() {
    const total = items.reduce((s, i) => s + i.qty, 0);
    document.querySelectorAll('.cart-count').forEach(el => {
      el.textContent = total;
      el.classList.toggle('visible', total > 0);
    });
  }

  function add(product) {
    const idx = items.findIndex(i => i.id === product.id && i.variant === product.variant);
    if (idx > -1) items[idx].qty += 1;
    else items.push({ ...product, qty: 1 });
    save(); renderSidebar(); openSidebar();
  }

  function remove(id, variant) {
    items = items.filter(i => !(i.id === id && i.variant === variant));
    save(); renderSidebar();
  }

  function changeQty(id, variant, delta) {
    const idx = items.findIndex(i => i.id === id && i.variant === variant);
    if (idx === -1) return;
    items[idx].qty += delta;
    if (items[idx].qty <= 0) items.splice(idx, 1);
    save(); renderSidebar();
  }

  function total() { return items.reduce((s, i) => s + i.price * i.qty, 0); }
  function count() { return items.reduce((s, i) => s + i.qty, 0); }
  function getItems() { return [...items]; }
  function clear() { items = []; save(); renderSidebar(); }

  return { add, remove, changeQty, total, count, getItems, clear, updateBadge };
})();

// ===== CART SIDEBAR RENDER =====
function renderSidebar() {
  const el = document.getElementById('cart-items-list');
  if (!el) return;
  const items = Cart.getItems();
  if (items.length === 0) {
    el.innerHTML = '<div class="cart-empty">Your cart is empty.</div>';
  } else {
    el.innerHTML = items.map(item => `
      <div class="cart-item">
        <div class="cart-item-img">
          <svg viewBox="0 0 60 60" fill="none" style="width:38px">
            <rect x="10" y="10" width="40" height="40" rx="2" fill="#E8E4DC" stroke="#C4C0B8" stroke-width="1"/>
            <path d="M18 40 L30 20 L42 40" stroke="#A8A49C" stroke-width="1.5" fill="none"/>
          </svg>
        </div>
        <div>
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-variant">${item.variant || ''}</div>
          <div class="cart-item-qty">
            <button class="qty-btn" onclick="Cart.changeQty('${item.id}','${item.variant || ''}',-1)">−</button>
            <span class="qty-num">${item.qty}</span>
            <button class="qty-btn" onclick="Cart.changeQty('${item.id}','${item.variant || ''}',1)">+</button>
          </div>
        </div>
        <div class="cart-item-price">₹${(item.price * item.qty).toLocaleString()}</div>
      </div>
    `).join('');
  }
  const sub = document.getElementById('cart-subtotal-val');
  if (sub) sub.textContent = '₹' + Cart.total().toLocaleString();
}

function openSidebar() {
  document.getElementById('cart-sidebar')?.classList.add('open');
  document.getElementById('cart-overlay')?.classList.add('open');
  renderSidebar();
}
function closeSidebar() {
  document.getElementById('cart-sidebar')?.classList.remove('open');
  document.getElementById('cart-overlay')?.classList.remove('open');
}

// ===== RAZORPAY CHECKOUT =====
function initiateCheckout() {
  const items  = Cart.getItems();
  if (items.length === 0) return;
  const amount = Cart.total(); // in INR

  // Razorpay options — replace key_id with your live key
  const options = {
    key: 'rzp_test_REPLACE_WITH_YOUR_KEY',   // ← REPLACE with your Razorpay Key ID
    amount: amount * 100,                     // paise
    currency: 'INR',
    name: 'TriAkar',
    description: `${Cart.count()} item(s) — designed in India`,
    image: '',  // add your logo URL
    prefill: {},
    theme: { color: '#181818' },
    handler: function(response) {
      Cart.clear();
      closeSidebar();
      showOrderSuccess(response.razorpay_payment_id);
    },
    modal: {
      ondismiss: function() { console.log('Checkout closed'); }
    }
  };

  if (typeof Razorpay === 'undefined') {
    // Load Razorpay script dynamically
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => new Razorpay(options).open();
    document.head.appendChild(script);
  } else {
    new Razorpay(options).open();
  }
}

function showOrderSuccess(paymentId) {
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;';
  el.innerHTML = `
    <div style="background:white;padding:52px 48px;max-width:440px;width:90%;text-align:center;">
      <div style="font-size:32px;margin-bottom:16px;">✓</div>
      <h3 style="font-family:var(--font-body);font-size:20px;font-weight:600;margin-bottom:12px;">Order Confirmed</h3>
      <p style="font-size:13px;color:var(--warm-mid);line-height:1.7;margin-bottom:8px;">
        Thank you for ordering from TriAkar. We'll start making your item(s) now.
      </p>
      <p style="font-size:11px;color:var(--stone);margin-bottom:28px;">Payment ID: ${paymentId}</p>
      <p style="font-size:12px;color:var(--stone);">Expect a confirmation email shortly.<br>Questions? <a href="mailto:hello@triakar.com" style="color:var(--accent)">hello@triakar.com</a></p>
      <button onclick="this.closest('div[style]').remove()" style="margin-top:28px;padding:12px 32px;background:var(--charcoal);color:white;border:none;font-size:11px;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;">
        Continue Shopping
      </button>
    </div>
  `;
  document.body.appendChild(el);
}

// Init on load
document.addEventListener('DOMContentLoaded', () => {
  Cart.updateBadge();
  renderSidebar();
});
