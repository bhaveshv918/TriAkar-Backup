# TriAkar — Website

## Pages
| File | Page |
|------|------|
| index.html | Homepage (animated 3D print hero, featured products, custom CTA, updates teaser) |
| products.html | Full product catalogue (filterable by category, sortable) |
| product-detail.html | Single product page (variants, qty, Add to Cart, Buy Now / Razorpay) |
| custom.html | Custom 3D printing (process, services, case studies, enquiry form) |
| updates.html | Work journal — recent projects + industry posts |
| about.html | About TriAkar, manufacturing, 7+ years story |
| contact.html | Contact form + hello@triakar.com |
| refund-policy.html | Returns & refund policy |
| terms.html | Terms & conditions |
| privacy.html | Privacy policy |
| shared.css | Shared styles (font system, nav, footer, cart sidebar) |
| shared.js | Cart logic, Razorpay checkout, cursor, scroll reveal |

## Razorpay Setup
1. Log into your Razorpay dashboard
2. Get your **Key ID** from Settings → API Keys
3. Open `shared.js` and replace `'rzp_test_REPLACE_WITH_YOUR_KEY'` with your key
4. For production: also set up a backend endpoint to verify payment signatures

## Font System
- **Glorida** — Logo + page H1 title only (embedded as base64)
- **Manrope** — All body text, headings h2–h6, buttons, labels, UI
- **Noto Sans Devanagari** — Hindi/Devanagari text only

## Deploy to GitHub Pages
```bash
git init
git add .
git commit -m "TriAkar website v2"
git branch -M main
git remote add origin https://github.com/YOURUSERNAME/triakar.git
git push -u origin main
```
Then in GitHub repo Settings → Pages → Source: main branch, root folder.

## Before Going Live — Checklist
- [ ] Replace Razorpay test key with live key in `shared.js`
- [ ] Add a backend/webhook to verify Razorpay payment signatures
- [ ] Replace SVG product illustrations with real product photography
- [ ] Update product prices, descriptions, and variant options in `products.html` and `product-detail.html`
- [ ] Connect contact/custom forms to an email service (Formspree, EmailJS, or backend)
- [ ] Add Google Analytics or Plausible if needed
- [ ] Add real product images, about-page photo
